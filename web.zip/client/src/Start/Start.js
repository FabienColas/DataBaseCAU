import React, { Component } from 'react';
import "./Start.css"
import {Icon} from "semantic-ui-react"



// import {Grid} from "semantic-ui-react"

class Start extends Component {
  constructor(props) {
    super(props)
    this.state = {
    }
  }

  componentDidMount() {
    //fetch("http://localhost:8080/api/getuserWidgets/" + sessionStorage.getItem("user")).then(res => res.json()).then(widgets => this.setState({widgets}));
  }

  render() {
    // keys = Object.keys(this.state.widgets.data)
    return (
      <div className="start">
        <div>
				
        </div>
      </div>
    );
  }
}

export default Start;