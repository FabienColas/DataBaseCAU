import React, { Component } from 'react';
import "./footer.css"
class Footer extends Component {
  render() {
    return (
        <div className="footer-parent">
          <div className="footer">
            Copyright 2018 VK empire
          </div>
        </div>
    );
  }
}

export default Footer;